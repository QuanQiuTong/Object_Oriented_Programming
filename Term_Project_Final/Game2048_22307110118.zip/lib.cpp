#include "lib.h"
Random random;